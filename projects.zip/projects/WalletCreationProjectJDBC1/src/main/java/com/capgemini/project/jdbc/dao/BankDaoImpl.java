package com.capgemini.project.jdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.capgemini.project.jdbc.bean.BankBean;



public class BankDaoImpl implements BankDao {
	//connection of database
	ConnectionDatabase cd = new ConnectionDatabase();
	PreparedStatement ps;
	Connection con;

	public long getBalance(long accNo) throws ClassNotFoundException, SQLException {
		con = cd.getConnection();
		ps = con.prepareStatement("Select * from user1 where accno=?");
		ps.setLong(1, accNo);
		ResultSet resultset = ps.executeQuery();
		resultset.next();
		return resultset.getLong(5);

	}

	public void setBalance(long accNo, long bal, String st) throws ClassNotFoundException, SQLException {
		con = cd.getConnection();
		ps = con.prepareStatement("Select * from user1 where accno=?");
		ps.setLong(1, accNo);
		ResultSet rs = ps.executeQuery();
		rs.next();
		String str = rs.getString(6) + st;
		ps = con.prepareStatement("update user1 set balance=?, Transaction=? where accno=?");
		ps.setLong(3, accNo);
		ps.setLong(1, bal);
		ps.setString(2, str);
		ps.executeUpdate();

	}

	public boolean checkMobile(long mob) throws ClassNotFoundException, SQLException {
		con = cd.getConnection();
		ps = con.prepareStatement("Select * from user1 where mobileno=?");
		ps.setLong(1, mob);
		ResultSet rs = ps.executeQuery();
		if (rs.next())
			return false;
		else
			return true;

	}

	public boolean checkPassword(String str) throws ClassNotFoundException, SQLException {
		con = cd.getConnection();
		ps = con.prepareStatement("Select * from user1 where password1=?");
		ps.setString(1, str);
		ResultSet rs = ps.executeQuery();
		if (rs.next())
			return true;
		else
			return false;

	}

	public boolean checkAccNo(long accNo) throws ClassNotFoundException, SQLException {
		con = cd.getConnection();
		ps = con.prepareStatement("Select * from user1 where accno=?");
		ps.setLong(1, accNo);
		ResultSet rs = ps.executeQuery();
		if (rs.next())
			return true;
		else
			return false;

	}

	public void setData(BankBean bb) throws ClassNotFoundException, SQLException {
		con = cd.getConnection();
		ps = con.prepareStatement("insert into user1 values(?,?,?,?,?,?)");
		ps.setString(1, bb.getName());
		ps.setLong(2, bb.getAccno());
		ps.setLong(3, bb.getMobileno());
		ps.setString(4, bb.getPassword1());
		ps.setLong(5, bb.getBalance());
		ps.setString(6, bb.getTransaction());

		int ans = ps.executeUpdate();

	}

	public String getTransaction(long accNo) throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		con = cd.getConnection();
		ps = con.prepareStatement("Select * from user1 where accno=?");
		ps.setLong(1, accNo);
		ResultSet rs = ps.executeQuery();
		rs.next();
		return rs.getString(6);
	}

	public BankBean getInfo(long accNo) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		con = cd.getConnection();
		ps = con.prepareStatement("Select * from user1 where accno=?");
		ps.setLong(1, accNo);
		ResultSet rs = ps.executeQuery();
		rs.next();
		BankBean b=new BankBean(rs.getString(1),rs.getLong(2), rs.getLong(3), rs.getString(4), rs.getLong(5),rs.getString(6));
		return b;
	}

	
}
