package com.capgemini.project.jdbc.bean;

import java.sql.SQLException;

//Start of bean class 
public class BankBean {

	//Declaration of variables used in bean class
	private String name;
	private long mobileno;
	private long balance;
	private String password;
	private String transaction;
	private long accno;
	int i = 0;
	
	
	//Start of getters and setters for the declared variables
	public String getName() {
		return name;
	}

	public void setAccNo(long accno) {
		this.accno = accno;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setTransaction(String transaction) {
		this.transaction = transaction;
		i++;
	}

	public long getMobileno() {
		return mobileno;
	}

	public long getAccno() {
		return accno;
	}

	public long getBalance() {
		return balance;
	}

	public void setBalance(long balance) {
		this.balance = balance;
	}

	public boolean getPassword(String password) {
		if (this.password.equals(password))
			return true;
		else
			return false;
	}

	public String getPassword1() {
		return password;

	}

	public void setMobileno(int mobileno) {
		this.mobileno = mobileno;
	}
	
	public String getTransaction() {
		return transaction;
	}

	public void setTransaction1(String transaction) {
		this.transaction = transaction;
	}

	public String getPassword() {
		return password;
	}

	public void setMobileno(long mobileno) {
		this.mobileno = mobileno;
	}

	public void setPassword(String password) {
		this.password = password;
	}
//End of getters and setters
	
	
//Start of constructor with parameters
	public BankBean(String name, long accno, long mobileno, String password, long balance, String tansaction)
			throws SQLException {

		this.name = name;
		this.mobileno = mobileno;
		this.password = password;
		balance = balance;
		transaction = tansaction;
		this.accno = accno;
		i++;
	}

	
	//Converting to string
	@Override
	public String toString() {
		return "CreateAccount [i=" + i + ", name=" + name + ",  mobileno=" + mobileno
				+ ", balance=" + balance + ", password=" + password + ", transaction=" + transaction + "]";
	}

}