package com.capgemini.project.jdbc.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionDatabase {
	private static Connection conn;
	public Connection getConnection() throws ClassNotFoundException, SQLException {
		try {
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/Projectdb","root","root");
		}
		catch(SQLException e)
		{
			throw e;
		}
		return conn;
	}
}
