package com.capgemini.project.jdbc.dao;

import java.sql.SQLException;
import java.util.HashMap;

import com.capgemini.project.jdbc.bean.BankBean;




//BankDaoImpl implements BankDao
public class BankDaoImpl implements BankDao {

	HashMap hm = new HashMap();	  //Creation of hashmap
	BankBean bb1;                  //object of bean class
	
	
	//start of method implementation from BankDao along with exception handling
	public long getBalance(long accno) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		if (hm.containsKey(accno)) {
			bb1 = (BankBean) hm.get(accno);
			return bb1.getBalance();
		} else
			return 9999;
	}
		
	

	public void setBalance(long accno, long balance, String str) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		if (hm.containsKey(accno)) {
			bb1 = (BankBean) hm.get(accno);
			bb1.setBalance(balance);
			String str1 = bb1.getTran() + str;
			bb1.setTran(str1);

		}
	}

	public boolean checkMobile(String mobileno) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		if (hm.containsKey(mobileno + 10000))
			return false;
		else
			return true;

		
	}

	public boolean checkAccNo(long accno) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		if (hm.containsKey(accno))
			return true;
		else
			return false;
	}

	public void setData(BankBean bb) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		hm.put(bb.getAccNo(), bb);
	}

	public String getTransaction(long accno) {
		// TODO Auto-generated method stub
		if (hm.containsKey(accno)) {
			bb1 = (BankBean) hm.get(accno);
			return bb1.getTran();
		} else
			return " ";
	}

	public boolean checkPassword(String str, long accno) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		if (hm.containsKey(accno)) {
			bb1 = (BankBean) hm.get(accno);
			if (str.equals(bb1.getPassword())) {
				return true;
			}
			return false;
		} else
			return false;
	}

	public BankBean getInfo(long accno) {
		// TODO Auto-generated method stub
		BankBean b=(BankBean)hm.get(accno);
		return b;
	}
	//End of implementation of methods

}
