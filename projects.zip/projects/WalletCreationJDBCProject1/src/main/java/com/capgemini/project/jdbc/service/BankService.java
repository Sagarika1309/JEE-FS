package com.capgemini.project.jdbc.service;

import java.sql.SQLException;

import com.capgemini.project.jdbc.bean.BankBean;
import com.capgemini.project.jdbc.dao.BankDao;



//Service layer as interface with methods
public interface BankService {

	long getBalance(long accno) throws ClassNotFoundException, SQLException;

	String getTransaction(long accno) throws ClassNotFoundException, SQLException;

	void setBalance(long accno, long balance, String str) throws ClassNotFoundException, SQLException;

	boolean checkAccNo(long accno) throws ClassNotFoundException, SQLException;

	boolean checkPass(String str, long accno) throws ClassNotFoundException, SQLException;

	boolean checkName(String name);

	boolean checkM(String mobileno);

	boolean checkP(String password);

	String addAccount(String name, String mobile, String password,int i) throws SQLException, ClassNotFoundException;

	BankBean getInfo(long accno);
	
}
