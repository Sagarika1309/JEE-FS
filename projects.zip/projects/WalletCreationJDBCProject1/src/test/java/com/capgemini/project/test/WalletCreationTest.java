package com.capgemini.project.test;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;

import com.capgemini.project.jdbc.bean.*;
import com.capgemini.project.jdbc.dao.*;
import com.capgemini.project.jdbc.service.*;
import com.capgemini.project.jdbc.ui.*;
public class WalletCreationTest {

	BankDao dao;
	@BeforeAll
	void intialize(){
		dao=new BankDaoImpl();
	}
	@Test
	void addAccount(String name, String mobile, String password,int i) throws SQLException, ClassNotFoundException {
		
		BankService user = new BankServiceImpl();
		BankBean user1=new BankBean();
		user1.setName("Saisree");
		user1.setMobile("9012346754");
		user1.setPassword("sai1234");
		HashMap hm=new HashMap();
		hm.put("9012346754",user1);
		
	}
	
	/*{
		Account user=new Account();
		user.setName("Ravi");
		user.setPhoneNumber(8898898890L);
		user.setEmailid("ravi@gmail.com");
		user.setBalance(0);
		Map<String, Account> expectedMap= new HashMap<String, Account>();
		expectedMap.put("8787879", user);
		dao.createAccount("8475757", user);
		Map<String, Account> actualMap=new HashMap<String, Account>();
		actualMap=dao.getAllAccounts();
		assertEquals(expectedMap.size(), actualMap.size());
	}
	*/
}
