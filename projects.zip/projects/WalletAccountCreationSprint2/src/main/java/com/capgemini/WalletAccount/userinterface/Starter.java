package com.capgemini.WalletAccount.userinterface;

import java.sql.ResultSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;

import com.capgemini.WalletAccount.bean.BankBean;
import com.capgemini.WalletAccount.service.BankServiceImpl;


public class Starter {
	static BankServiceImpl service=new BankServiceImpl();
	public static void showMenu() {
		System.out.println("Menu:");
		System.out.println("01. Create an Account");
		System.out.println("02. Add Money to Account");
		System.out.println("03. Show Details");
		System.out.println("04. Transfer Money");
		System.out.println("05. Show All Accounts");
		System.out.println("06. Exit");  /* 9996269  9117049*/
		System.out.print("Enter Your Choice : ");
	}
	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		int choice;
		while(true)
		{
			showMenu();
			choice = scanner.nextInt();
			switch(choice)
			{
			case 1:
				System.out.println("Wallet Account Creation");
				try
				{
					BankBean user=new BankBean();
					System.out.println("Enter your name:");
					user.setaccName(scanner.next());
					System.out.println("Enter your Mobile number:");
					user.setMobileNumber(scanner.nextLong());
					System.out.println("Enter your E-mail:");
					user.setEm_id(scanner.next());
					user.setaccBalance(0);
					String AccountNumber=service.createBankAccount(user);
					System.out.println("Your Wallet Account Number is : "+AccountNumber);
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				break;
			case 2:
				
				try {
					System.out.println("Enter the wallet account number to credit money:");
					String AccountNumber=scanner.next();
					System.out.println("Enter the amount to credit in to the wallet account "+AccountNumber);
					int Amount=scanner.nextInt();
					service.creditMoney(AccountNumber, Amount);
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				break;
			case 3:
				
				try
				{
					System.out.println("Enter the Wallet Account Number");
					String AccountNumber=scanner.next();
					BankBean user=service.viewBankAccount(AccountNumber);
					System.out.println("Name="+user.getaccName()+"\nMobile No="+user.getMobileNumber()+"\nEmail="+user.getEm_id()+"\nBalance="+user.getaccBalance());
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				break;
			case 4:
				
				try
				{
					System.out.println("Enter the sender Wallet Account Number");
					String SenderAccountNumber=scanner.next();
					System.out.println("Enter the Reciever Wallet Account Number");
					String RecieverAccountNumber=scanner.next();
					System.out.println("Enter the amount to be transferred");
					int TransferAmount=scanner.nextInt();
					service.transfer(SenderAccountNumber, RecieverAccountNumber, TransferAmount);
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				break;
			case 5:
				try
				{
					ResultSet rs=service.getAllWalletAccounts();
					while(rs.next())
					{
						System.out.println("Account Number: "+rs.getString(1)+"\nName: "+rs.getString(2));
					}
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				break;
			case 6:
				System.exit(0);
			default:
				break;
			}
		}
	}

}
