package com.capgemini.WalletAccount.exceptions;
@SuppressWarnings("serial")
public class InvalidMobileNumberException extends Exception{
	public InvalidMobileNumberException()
	{
		super("The Phone number is in invalid Format");
	}

}
