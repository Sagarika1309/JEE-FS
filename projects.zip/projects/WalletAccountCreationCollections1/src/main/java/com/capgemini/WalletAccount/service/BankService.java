package com.capgemini.WalletAccount.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;

import com.capgemini.WalletAccount.bean.BankBean;
import com.capgemini.WalletAccount.exceptions.BankAccountException;
import com.capgemini.WalletAccount.exceptions.BankAccountNotFoundException;
import com.capgemini.WalletAccount.exceptions.InsuffecientBankBalanceException;
import com.capgemini.WalletAccount.exceptions.InvalidEMailException;
import com.capgemini.WalletAccount.exceptions.InvalidMobileNumberException;



public interface BankService {
	public String createAccountDao(BankBean user) throws InvalidEMailException, InvalidMobileNumberException, SQLException, Exception;
	public BankBean viewAccount(String accountNumber) throws BankAccountNotFoundException, Exception;
	public void addMoney(String accountNumber, int amount) throws BankAccountNotFoundException, SQLException, Exception;
	public void transfer(String accountNumber1,String accountNumber2, int amount) throws InsuffecientBankBalanceException, BankAccountNotFoundException, BankAccountException, Exception;
	public ResultSet getAllAccounts() throws Exception;
}
