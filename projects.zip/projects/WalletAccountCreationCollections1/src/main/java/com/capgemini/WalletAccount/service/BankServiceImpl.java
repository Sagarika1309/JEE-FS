package com.capgemini.WalletAccount.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Random;

import com.capgemini.WalletAccount.bean.BankBean;
import com.capgemini.WalletAccount.dao.BankDao;
import com.capgemini.WalletAccount.dao.BankDaoImpl;


public class BankServiceImpl extends Validator implements BankService{
	BankDao dao=new BankDaoImpl();
	Validator v=new Validator();
	int row;
	public String createAccountDao(BankBean user) throws Exception{
		// TODO Auto-generated method stub
		String accountNumber=null;
		try 
		{
			v.validator(user);
			Random rand=new Random();
			int num=rand.nextInt(9000000)+1000000;
			accountNumber=String.valueOf(num);
			dao.createBankAccount(accountNumber, user);
			return accountNumber;
		}
		catch(Exception e)
		{
			throw e;
		}
		
	}


	public BankBean viewAccount(String accountNumber) throws Exception{

		try
		{
			return dao.viewBankAccount(accountNumber);
		}
		catch(Exception e)
		{
			throw e;
		}
	}

	public void addMoney(String accountNumber, int amount) throws Exception {
		// TODO Auto-generated method stub
		try
		{
			dao.creditMoney(accountNumber, amount);
		}
		catch(Exception e)
		{
			throw e;
		}
		
	}

	public void transfer(String accountNumber1, String accountNumber2, int amount) throws Exception {
		// TODO Auto-generated method stub
		try {
			dao.debitMoney(accountNumber1, accountNumber2, amount);
			}
		catch(Exception e)
		{
			throw e;
		}
		
	}


	public ResultSet getAllAccounts() throws Exception {
		// TODO Auto-generated method stub
		try {
			return dao.getAllAccounts();
		}
		catch(Exception e)
		{
			throw e;
		}
	}

}
