package com.capgemini.WalletAccount.service;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.WalletAccount.bean.BankBean;
import com.capgemini.WalletAccount.exceptions.InvalidEMailException;
import com.capgemini.WalletAccount.exceptions.InvalidMobileNumberException;


public class Validator {
	boolean result=false;
	boolean result1=false;
	boolean result2=false;
	public void validator(BankBean user) throws InvalidEMailException,InvalidMobileNumberException
	{
		try {
			validatePhoneNumber(user.getMobileNumber());
			validateEmail(user.getEm_id());
			
		} catch (InvalidMobileNumberException | InvalidEMailException e) {
			// TODO Auto-generated catch block
			throw e;
		}
	}
	public void validateEmail(String string) throws InvalidEMailException
	{
	
			Pattern p = Pattern.compile("\\b[a-zA-Z0-9._%-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}\\b");
			Matcher m = p.matcher(string);
			if(!m.matches())
			{
				throw new InvalidEMailException();
			}
	
	}
	public void validatePhoneNumber(long phone) throws InvalidMobileNumberException
	{
			String temp=String.valueOf(phone);
			Pattern p = Pattern.compile("\\d{10}");
			Matcher m = p.matcher(temp);
			if(!m.matches() || (!(temp.length()==10)))
			{
				throw new InvalidMobileNumberException();
			}
	}
	
}
