package com.capgemini.WalletAccount.exceptions;

@SuppressWarnings("serial")
public class BankAccountNotFoundException extends Exception{
	public BankAccountNotFoundException()
	{
		super("The Account Number is not found");
	}

}
