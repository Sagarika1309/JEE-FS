package com.capgemini.collection.test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;

import com.capgemini.collection.bean.BankBean;
import com.capgemini.collection.exception.BankAccountException;
import com.capgemini.collection.exception.BankAccountNotFoundException;
import com.capgemini.collection.exception.InsuffecientBankBalanceException;
import com.capgemini.collection.exception.InvalidEMailException;
import com.capgemini.collection.exception.InvalidMobileNumberException;
import com.capgemini.collection.service.BankService;
import com.capgemini.collection.service.BankServiceImpl;

@TestInstance(Lifecycle.PER_CLASS)
class BankTest {
	BankService service;
	@BeforeAll
	void intialize(){
		service=new BankServiceImpl();
	}
	
	@Test
	void testCreateAccount() throws InvalidEMailException, InvalidMobileNumberException
	{
		BankBean user=new BankBean();
		user.setaccName("Saisree");
		user.setMobileNumber(3765176894L);
		user.setaccBalance(1000);
		user.setEm_id("Saisree@gmail.com");
		String string=service.newBankAccount(user);
		assertNotEquals(null, string);
	}
	
	@Test
	void testaddMoney() throws  BankAccountNotFoundException{
		BankBean user=new BankBean();
		String accountNumber=null;
		Map<String, BankBean> list=new HashMap<String, BankBean>();
		list=service.getAllWalletAccounts();
		Set<Entry<String, BankBean>> set=list.entrySet();
		Iterator<Entry<String, BankBean>> i=set.iterator();
		while(i.hasNext())
		{
			Map.Entry<String, BankBean> list1=(Map.Entry<String, BankBean>)i.next();
			accountNumber=list1.getKey();
			user=list1.getValue();
		}
		if(service.creditMoney(accountNumber, 1000))
		{
			assertTrue(true);
		}
		else
		{
			assertFalse(false);
		}
	}
	
	@Test
	void testTransfer() throws InvalidEMailException , InvalidMobileNumberException, InsuffecientBankBalanceException,  BankAccountException, BankAccountNotFoundException
	{
		BankBean user=new BankBean();
		List<String> list=new ArrayList<String>();
		user.setaccName("Saisree");
		user.setMobileNumber(4761541227L);
		user.setaccBalance(2000);
		user.setEm_id("Saisree@gmail.com");
		service.newBankAccount(user);
		Map<String, BankBean> luser=new HashMap<String, BankBean>();
		luser=service.getAllWalletAccounts();
		Set<Entry<String, BankBean>> set=luser.entrySet();
		Iterator<Entry<String, BankBean>> i=set.iterator();
		while(i.hasNext())
		{
			Map.Entry<String, BankBean> map=(Map.Entry<String, BankBean>)i.next();
			list.add(map.getKey());
		}
		if(service.debitAmount(list.get(0), list.get(1), 1000))
		{
			assertTrue(true);
		}
		else
		{
			assertFalse(false);
		}
	}
}