package com.capgemini.collection.service;

import java.util.HashMap;

import com.capgemini.collection.bean.BankBean;
import com.capgemini.collection.exception.BankAccountException;
import com.capgemini.collection.exception.BankAccountNotFoundException;
import com.capgemini.collection.exception.InsuffecientBankBalanceException;
import com.capgemini.collection.exception.InvalidEMailException;
import com.capgemini.collection.exception.InvalidMobileNumberException;



public interface BankService {
	public String newBankAccount(BankBean user) throws InvalidEMailException, InvalidMobileNumberException;
	public BankBean showBankAccount(String AccountNumber) throws BankAccountNotFoundException;
	public boolean creditMoney(String AccountNumber, int Amount) throws BankAccountNotFoundException;
	public boolean debitAmount(String AccountNumber1,String AccountNumber2, int Amount) throws InsuffecientBankBalanceException, BankAccountNotFoundException, BankAccountException;
	public HashMap<String, BankBean> getAllWalletAccounts();
}
