package com.capgemini.collection.dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.collection.bean.BankBean;
import com.capgemini.collection.exception.BankAccountException;
import com.capgemini.collection.exception.BankAccountNotFoundException;
import com.capgemini.collection.exception.InsuffecientBankBalanceException;



public class BankDaoImpl implements BankDao{
	Map<String, BankBean> userList=new HashMap<String, BankBean>();

	@Override
	public void createBankAccount(String accountNumber, BankBean user) 
	{
		try 
		{
			userList.put(accountNumber, user);
		}
		catch(Exception e)
		{
			throw e;
		}
		}

	@Override
	public BankBean viewBankAccount(String accountNumber) throws BankAccountNotFoundException
	{
		try 
		{
			validateBankAccount(accountNumber);
			BankBean user=new BankBean();
			user=userList.get(accountNumber);
			return user;
		}
		catch(Exception e) {
			throw e;
		}
	}

	@Override
	public boolean creditMoney(String accountNumber, int amount) throws BankAccountNotFoundException
	{
	try
	{
			validateBankAccount(accountNumber);
			BankBean user=new BankBean();
			user=userList.get(accountNumber);
			int temp=user.getaccBalance();
			temp=temp+amount;
			user.setaccBalance(temp);
			return true;
			
		}
		catch(Exception e)
		{
			throw e;
		}
		
	}

	@Override
	public boolean debitMoney(String accNumber1, String accNumber2, int amount) throws InsuffecientBankBalanceException,BankAccountNotFoundException,BankAccountException 
	{
		try 
		{
				validateBankAccount(accNumber1);
				validateBankAccount(accNumber2);
				if(!accNumber1.equals(accNumber2))
				{
				checkSuffecientBankBalance(accNumber1, amount);
				BankBean user1=userList.get(accNumber1);
				BankBean user2=userList.get(accNumber2);
				int temp1=user1.getaccBalance();
				int temp2=user2.getaccBalance();
				temp1=temp1-amount;
				temp2=temp2+amount;
				user1.setaccBalance(temp1);
				user2.setaccBalance(temp2);
				return true;
			}
				else
				{
					throw new BankAccountException();
				}
		}
			catch(Exception e)
			{
				throw e;
			}
		
	}
	@Override
	public void checkSuffecientBankBalance(String accNumber1, int amount) throws InsuffecientBankBalanceException {
		
		try {
			BankBean user=userList.get(accNumber1);
			if(user.getaccBalance()<amount)
			{
				throw new InsuffecientBankBalanceException();
			}
		}
		catch(Exception e)
		{
			throw e;
		}
	}

	@Override
	public void validateBankAccount(String accountNumber) throws BankAccountNotFoundException 
	{
	
		try
		{
			if(!userList.containsKey(accountNumber))
			{
				throw new BankAccountNotFoundException();
			}
		}
		catch(Exception e)
		{
			throw e;
		}
	}

	@Override
	public HashMap<String, BankBean> getAllWalletAccounts() 
	{
try
		{
			return (HashMap<String, BankBean>) userList;
		}
		catch(Exception e)
		{
			throw e;
		}
	}

}
