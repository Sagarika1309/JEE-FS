package com.capgemini.collection.exception;

@SuppressWarnings("serial")
public class InvalidEMailException extends Exception {
	public InvalidEMailException()
	{
		super("Check the Mail Id you have Entered");
	}

}
