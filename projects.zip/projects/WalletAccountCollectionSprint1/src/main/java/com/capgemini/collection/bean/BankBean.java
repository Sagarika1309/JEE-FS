package com.capgemini.collection.bean;

public class BankBean {
	private String accName;
	private long mobileNumber;
	private String em_id;
	private int accBalance;
	public String getaccName() {
		return accName;
	}
	public void setaccName(String accName) {
		this.accName = accName;
	}
	public long getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getEm_id() {
		return em_id;
	}
	public void setEm_id(String em_id) {
		this.em_id = em_id;
	}
	public int getaccBalance() {
		return accBalance;
	}
	public void setaccBalance(int accBalance) {
		this.accBalance = accBalance;
	}

}
