import { Injectable } from '@angular/core';
import{ Observable } from '../../node_modules/rxjs';

import { productDetails } from './product-brands/productDetails';
import { HttpClient } from '@angular/common/http';



@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor(private http:HttpClient) { }

  url:string='/assets/productDetails.json';
      
    getAllProducts(): Observable<productDetails[]>{
      return this.http.get<productDetails[]>(this.url);

   }
}
