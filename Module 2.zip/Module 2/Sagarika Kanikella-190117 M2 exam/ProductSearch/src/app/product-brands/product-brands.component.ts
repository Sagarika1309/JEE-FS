import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { ActivatedRoute } from '@angular/router';
import { productDetails } from './productDetails';


@Component({
  selector: 'app-product-brands',
  templateUrl: './product-brands.component.html',
  styleUrls: ['./product-brands.component.css']
})
export class ProductBrandsComponent implements OnInit {

  productList:productDetails[];
  
  constructor(private service:ProductService) { }

  ngOnInit() {
    this.getAllProducts();
  }

  getAllProducts()
  {
    this.service.getAllProducts().subscribe(data=>this.productList=data);
  }
}
