package com.capg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.capg.bean.Product;
import com.capg.service.ProductService;

@Controller
public class ProductController {

	@Autowired
	ProductService service;
	
	@RequestMapping(value="/Post")
	public String productForm() {
		return "product";
	}
	
	@RequestMapping(value="/addProduct")
	public ModelAndView addProduct(Product product) {
		service.addProduct(product);
		ModelAndView mv = new ModelAndView();
		mv.addObject("product",product);
		mv.setViewName("display");
		return mv;
		
	}
	
	@RequestMapping(value="/getAll")
	public ModelAndView displayAll() {
		ModelAndView mv = new ModelAndView();
		List<Product> productList = service.getAll();
		mv.addObject("product",productList);
		mv.setViewName("displayAll");
		return mv;
	}
	
}
