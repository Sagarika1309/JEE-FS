package com.spg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		
		
		ApplicationContext context = SpringApplication.run(Application.class, args);
		Employee emp = context.getBean(Employee.class);
		emp.setEmployeeId(12345);
		emp.setEmployeeName("Harriet");
		emp.setSalary(40000);
		emp.setBusinessUnit("PES-BU");
		emp.setAge(30);
		
		System.out.println("Employee Details");
		System.out.println("-------------------------------------------");
		System.out.println("Employee ID :" + emp.getEmployeeId());
		System.out.println("Employee Name :" + emp.getEmployeeName());
		System.out.println("Employee Salary :" + emp.getSalary());
		System.out.println("Employee BU :" + emp.getBusinessUnit());
		System.out.println("Employee Age :" + emp.getAge());

		
		
		
	}

}
