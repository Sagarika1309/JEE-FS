package com.capg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.capg.Exception.TraineeNotFoundException;
import com.capg.bean.Trainee;
import com.capg.service.TraineeService;

@RestController
public class TraineeController {
	
	@Autowired
	TraineeService service;

	
	//Insert Trainee
	@PostMapping(value="/trainee", consumes= {"application/json"})
	public ResponseEntity<String> insertTrainee(@RequestBody Trainee trainee) {
		service.insertTrainee(trainee);
		return new ResponseEntity<String>("Trainee Added.",HttpStatus.OK);
	}
	
	
	//Update Trainee
	@PutMapping(value="/trainee", consumes= {"application/json"})
	public ResponseEntity<String> updateTrainee(@RequestBody Trainee trainee) {
		service.updateTrainee(trainee);
		return new ResponseEntity<String>("Trainee Updated.", HttpStatus.OK);
	}
	
	
	//Get Trainee By ID
	@GetMapping(value="/trainee/{traineeId}")
	public Trainee getTrainee(@PathVariable int traineeId) throws TraineeNotFoundException {
		Trainee trainee = service.getTrainee(traineeId);
		if(trainee == null)
			throw new TraineeNotFoundException();
		else
			return trainee;
	}
	
	
	//Get All Trainee
	@GetMapping(value="/trainee/all")
	public List<Trainee> getAllTrainee() {
		return service.getAllTrainee();
	}
	
	
	//Delete Trainee
	@DeleteMapping(value="/trainee/{traineeId}")
	public ResponseEntity<String> deleteTrainee(@PathVariable int traineeId) {
		service.deleteTrainee(traineeId);
		return new ResponseEntity<String>("Trainee Deleted.", HttpStatus.OK);
	}
	
	
	//Trainee not found exception handled
	@ResponseStatus(value=HttpStatus.NOT_FOUND, reason="Trainee ID not found.")
	@ExceptionHandler(value= {TraineeNotFoundException.class})
	public void traineeNotFoundHandled() {
		
	}
	
	
	//Any other exception handled
	@ResponseStatus(value=HttpStatus.NOT_FOUND, reason="Exception Occured.")
	@ExceptionHandler(value= {Exception.class})
	public void exceptionHandled() {
		
	}
	
	
}
