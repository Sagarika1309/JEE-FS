package com.cg.jpa.entites;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="author_store")
public class Author extends Book {
	private static final long serialVersionUID = 1L;
	
	private int authorId;
	private String name;
	
	public int getAuthorId() {
		return authorId;
	}
	public void setAuthorId(int authorId) {
		this.authorId = authorId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
