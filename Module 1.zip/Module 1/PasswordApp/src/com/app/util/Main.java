package com.app.util;

import java.util.Scanner;
import java.io.*;
public class Main
{

        public static void main(String args[])
        {
           Scanner scanner = new Scanner(System.in);
           String str = scanner.next();
           if(str.length() >= 5)
           {
        	   String result = generate(str);
        	   System.out.println(result);
           }
           else
        	   System.out.println("invalid input");
        }


        public static String generate(String s) 
        {
        	String result = "";
        	
        	for (int i = 0; i < s.length(); i = i + 2) 
        	{
              	char ch = s.charAt(i);
              	result = result + ch;
              
            }  
            	s = result.toString().toUpperCase();
        	return s;
           
        }
}
