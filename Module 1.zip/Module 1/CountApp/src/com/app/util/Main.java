package com.app.util;

import java.util.Scanner;

public class Main
{ 


	public static void main(String args[])
	{
		Scanner scanner = new Scanner(System.in);
		int a = scanner.nextInt();
		int b = scanner.nextInt();
		
		int result = count(a,b);
		
		System.out.println(result );
		
	}

	public static int count(int n1,int n2)   { 

		int count = 0;
		while(n1 != 0)
		{
			int output = n1 % 10;
			if(output == n2)
			{
				count++;
			}
			n1 = n1 / 10;
		}
		
		return count;

	}
}



