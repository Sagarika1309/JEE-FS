package com.app.util;

import java.util.Scanner;

public class Main
{


	public static void main(String args[])
	{
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the access code:");
		int code = scanner.nextInt();
		System.out.println(validateAccessCode(code));

	}

	public static String validateAccessCode(int accessCode)
	{
		int arr[] = new int[4];
		int sum = 0;
		int count = 0;
		while(accessCode > 0)
		{
			accessCode = accessCode / 10;
			count++;
		}
		if(count == 4)
		{
			for(int i = 0; i < arr.length ; i = i + 2)
			{
				sum = sum + arr[i];
			}
			if(sum % 2 == 0)
				System.out.println("valid code");
			else
				System.out.println("invalid access code");
		}
		else
			return "invalid input";
		return null;
		
	
	}
}