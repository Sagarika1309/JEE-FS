//make the necessary change to make this class a Exception 
public class SalaryNegativeException extends Exception 
{ 
	String s=""; 
	public SalaryNegativeException(String string) 
	{ 
		super(string); 
	}


}
	
