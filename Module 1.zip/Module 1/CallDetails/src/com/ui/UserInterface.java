package com.ui;

import java.util.Scanner;

public class UserInterface {
	
	public static void main(String a[]){
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the number of call details");
		int number = sc.nextInt();
		
		System.out.println("Enter the call details");
		for (int i = 0; i < a.length; i++) {
			
			String a1 = sc.next();
			
		}
		
		
	}

}
