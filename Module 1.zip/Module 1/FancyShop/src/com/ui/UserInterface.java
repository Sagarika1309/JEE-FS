package com.ui;

import java.util.Scanner;

public class UserInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc =new Scanner(System.in);
		//Fill the UI code
		System.out.println("Enter the no of Face Creams you want to store:");
		int number = sc.nextInt();
		for(int i = 1; i <= number; i++)
		{
			System.out.println("Enter the key"+i);
			int key = sc.nextInt();
			
			System.out.println("enter the value"+i);
			String value = sc.next();
		}
			

	}

}
