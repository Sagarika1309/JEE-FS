package capgemini_Lab5;

import java.util.Scanner;

public class Lab5_Ex4_EmployeeName {

	public static void main(String[] args) {
		String firstname,lastname;
		Scanner sc=new Scanner(System.in);
		firstname=sc.nextLine();
		lastname=sc.nextLine();
		sc.close();
		try{
			if(firstname.isEmpty()||lastname.isEmpty()) throw new Exception("invalid");
		}
		catch(Exception e)
		{
		System.err.println(e.getMessage());	
		}

	}

}
