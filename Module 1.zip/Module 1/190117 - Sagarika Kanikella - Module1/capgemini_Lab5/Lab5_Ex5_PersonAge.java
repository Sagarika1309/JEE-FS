package capgemini_Lab5;

import java.util.Scanner;

public class Lab5_Ex5_PersonAge {

	public static void main(String[] args) {
      int age;
      Scanner sc=new Scanner(System.in);
      age=sc.nextInt();
      try{
    	  if(age<=15) throw new Exception("Invalid age");
    	  else
    	  {
    		  System.out.println("age validated");
    	  }
    	  
      }
      catch(Exception e)
      {
    	 System.err.println(e.getMessage());
      }
	}

}
