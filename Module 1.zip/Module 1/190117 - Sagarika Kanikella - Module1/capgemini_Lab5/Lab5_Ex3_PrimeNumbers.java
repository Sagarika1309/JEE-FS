package capgemini_Lab5;

import java.util.Scanner;

public class Lab5_Ex3_PrimeNumbers {

	public static void main(String[] args) {

		int no;
		Scanner sc=new Scanner(System.in);
		no=sc.nextInt();
		Prime(no);
	}

	private static void Prime(int no) {
		for(int i=1;i<=no;i++)
		{
			int count=0;
			for(int j=1;j<=i;j++)
			{
				if(i%j==0)
				{
					count++;
				}
			}
			if(count==2)
			{
				System.out.print(i+" ");
			}
		}
		
	}

}
