package capgemini_Lab5;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
class Radiobutton extends JFrame implements ActionListener{
	private JRadioButton red;
	private JRadioButton orange;
	private JRadioButton green;
	private TextField t;
    Container container;
	
public Radiobutton()
{
	super("Radio Button Test");
	container = getContentPane();
	container.setLayout(new FlowLayout());
	setVisible(true);
	setSize(300,200);
	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	red=new JRadioButton(" red");
	orange=new JRadioButton(" orange");
	green=new JRadioButton(" green");
	t=new TextField();
	t.setBounds(1,50,50,500);
	ButtonGroup group=new ButtonGroup();
	group.add(red);
	group.add(orange);
	group.add(green);
	
	
	
	red.addActionListener(this);
	orange.addActionListener(this);
	green.addActionListener(this);
	container.add(red);
	container.add(orange);
	container.add(green);
	container.add(t);
}
public void actionPerformed(ActionEvent e)
{
	if(e.getSource()== red)
	{
		t.setText("stop");
		t.setBackground(Color.red);
		
	}
	if(e.getSource()== orange)
	{
		t.setText("ready");
		t.setBackground(Color.ORANGE);
	}
	
	if(e.getSource()== green)
	{
		t.setText("go");
		t.setBackground(Color.green);
	}
	
	
	}
	
}
public class Lab5_Ex1_TrafficLight {
	public static void main(String[] args)
	{
		Radiobutton r1=new Radiobutton();
				}
}