package capgemini_Lab5;
import com.cg.eis.exception.*;
import java.util.Scanner;

public class Lab5_Ex5_salary {

	private static Scanner sc;

	public static void main(String[] args) {
		int salary;
		sc = new Scanner(System.in);
		salary=sc.nextInt();
		try
		{
			if(salary<=3000) throw  new EmployeeException("Exception is:");
			else
			{
				System.out.println("salary is greater than 3000");
			}
		}
		catch(EmployeeException e)
		{
			e.printStackTrace();
		}
	}

}
