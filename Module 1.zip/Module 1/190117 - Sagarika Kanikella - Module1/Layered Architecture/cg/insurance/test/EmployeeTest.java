package com.cg.insurance.test;

import com.cg.bean.Employee;
import com.cg.dao.EmployeeDAO;

class EmployeeTest {
    static EmployeeDAO dao;
    Employee emp;



}
 













