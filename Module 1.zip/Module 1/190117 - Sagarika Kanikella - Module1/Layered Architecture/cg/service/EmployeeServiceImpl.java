package com.cg.service;

import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.bean.Employee;
import com.cg.dao.EmployeeDAO;
import com.cg.dao.EmployeeDAOImpl;

public class EmployeeServiceImpl implements EmployeeService {
	EmployeeDAO employeeDao = new EmployeeDAOImpl();

	public int addEmployee(Employee employee) {
		int empId = (int) (Math.random() * 1000);
		employee.setId(empId);
		return employeeDao.addEmployee(employee);
	}

	public Employee getEmployee(int employeeId) {
		return employeeDao.getEmployee(employeeId);
	}

	public HashMap<Integer, Employee> getEmployee() {
		return employeeDao.getEmployee();
	}

	public boolean isNameValid(String name) {
		Pattern nameptn = Pattern.compile("^[A-Z]{1}[a-z]{4,}$");
		Matcher match = nameptn.matcher(name);
		if (match.matches()) {
			return true;
		}
		return false;
	}

	public boolean isPhoneValid(String mobileNo) {
		String mobile = String.valueOf(mobileNo);
		Pattern nameptn = Pattern.compile("^[7-9]{1}[0-9]{9,}$");
		Matcher match = nameptn.matcher(mobileNo);
		if (match.matches()) {
			return true;
		}
		return false;
	}

}
