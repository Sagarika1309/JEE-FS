package com.cg.service;

import java.util.HashMap;

import com.cg.bean.Employee;

public interface EmployeeService {
	public int addEmployee(Employee employee);

	Employee getEmployee(int employeeId);

	HashMap<Integer, Employee> getEmployee();

}
