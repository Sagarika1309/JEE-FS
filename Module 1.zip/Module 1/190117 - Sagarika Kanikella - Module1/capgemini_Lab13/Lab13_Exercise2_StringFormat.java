package capgemini_Lab13;

import java.util.Scanner;

interface Format {
	StringBuilder StrFormat(StringBuilder builder);
}

public class Lab13_Exercise2_StringFormat {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		StringBuilder builder = new StringBuilder(scan.nextLine());
		StringBuilder b = new StringBuilder();
		Format format = (builder1) -> {
			for (int i = 0; i < builder1.length(); i++) {
				// System.out.print(builder1.charAt(i)+" ");
				b.append(builder1.charAt(i) + " ");
			}
			return b;
		};
		System.out.println(format.StrFormat(builder));
	}

}
