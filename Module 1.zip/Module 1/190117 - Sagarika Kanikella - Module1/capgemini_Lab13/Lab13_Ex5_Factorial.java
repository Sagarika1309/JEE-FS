package capgemini_Lab13;

import java.util.Scanner;
import java.util.function.IntConsumer;

public class Lab13_Ex5_Factorial {
	public static void factorial(int num) {
		int fact = 1;

		while (num > 0) {
			fact = fact * num;
			num--;
		}

		System.out.println(fact);

	}

	public static void main(String[] args) {

		IntConsumer c = Lab13_Ex5_Factorial::factorial;
		Scanner sc=new Scanner(System.in);
		c.accept(sc.nextInt());
	}
}
