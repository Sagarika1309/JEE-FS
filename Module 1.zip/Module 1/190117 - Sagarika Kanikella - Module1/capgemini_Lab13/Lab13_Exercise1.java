package capgemini_Lab13;

import java.util.Scanner;

@FunctionalInterface
interface MyImpl {
	int power(int x, int y);
}

public class Lab13_Exercise1 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);

		MyImpl myImpl = (x, y) -> {
			return (int) Math.pow(x, y);
		};

		System.out.println(myImpl.power(scan.nextInt(), scan.nextInt()));
	}

}
