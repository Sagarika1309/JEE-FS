package capgemini_Lab10;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

class CopyDataThread extends Thread {

	public CopyDataThread(FileInputStream fileInputStream, FileOutputStream fileOutputStream) {
		int count = 0;
		int b;
		try {
			b = fileInputStream.read();
			while (b != -1) {
				count++;
				fileOutputStream.write((char) b);
				if (count == 10) {
					System.out.println("10 characters are copied");
					Thread.sleep(5000);
					count = 0;
				}
				b = fileInputStream.read();
			}
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void run() {

	}
}

public class FileProgram {

	public static void main(String[] args) {
		File file = new File("C:\\capgemini\\maven.txt");
		try {
			FileInputStream fileInputStream = new FileInputStream(file);
			FileOutputStream fileOutputStream = new FileOutputStream("C:\\capgemini\\target.txt");
			CopyDataThread copyDataThread = new CopyDataThread(fileInputStream, fileOutputStream);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		Thread t1 = new Thread();
		t1.start();
	}

}
