package capgemini_Lab2;

class Cd extends MediaItem {
	 private String artist,genre;
	 @Override
	public int getRuntime() {
		return runtime;
	}

	public Cd(String artist, String genre) {
		setArtist(artist);
		setGenre(genre);
	}

	public Cd() {
		super();
		this.artist = null;
		this.genre = null;
	}

	public void setArtist(String artist) {
		this.artist = artist;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	@Override
	public void setUniqueIdentificationnumber(int uniqueIdentificationnumber) {
		this.uniqueIdentificationnumber = uniqueIdentificationnumber;
	}

	@Override
	public void setNumber_of_Copies(int number_of_Copies) {
		this.number_of_Copies = number_of_Copies;
	}

	@Override
	public void setRuntime(int runtime) {
		this.runtime=runtime;
	}

	@Override
	public void setTitle(String title) {
		this.Title = title;		
	}

	public String getArtist() {
		return artist;
	}

	public String getGenre() {
		return genre;
	}

	public int getUniqueIdentificationnumber() {
			return uniqueIdentificationnumber;
		}

		@Override
		public String getTitle() {
			return Title;
		}

		@Override
		public int getNumber_of_Copies() {
			return number_of_Copies;
		}

		@Override
public String toString() {
	// TODO Auto-generated method stub
	return "Artist="+getArtist()+"\nGenre="+getGenre()+"\nUniqueIdentificationNumber="+getUniqueIdentificationnumber()+"\nTitle="+getTitle()+"\nRuntime="+getRuntime()+"\nno of copies="+getNumber_of_Copies();
}
}
	


