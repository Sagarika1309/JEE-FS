package capgemini_Lab2;

class Book extends WrittenItem {

	@Override
	public String getAuthor() {
		return author;
	}

	@Override
	public void setAuthor(String author) {
		this.author = author;
	}

	@Override
	public int getUniqueIdentificationnumber() {
		return uniqueIdentificationnumber;
	}

	@Override
	public void setUniqueIdentificationnumber(int uniqueIdentificationnumber) {
		this.uniqueIdentificationnumber = uniqueIdentificationnumber;
	}

	@Override
	public String getTitle() {
		return Title;
	}

	@Override
	public void setTitle(String title) {
		this.Title = title;		
	}

	@Override
	public int getNumber_of_Copies() {
		return number_of_Copies;
	}

	@Override
	public void setNumber_of_Copies(int number_of_Copies) {
		this.number_of_Copies = number_of_Copies;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Author="+getAuthor()+"\nUniqueIdentificationNumber="+getUniqueIdentificationnumber()+"\nTitle="+getTitle()+"\nno of copies="+getNumber_of_Copies();
	}
	
}
