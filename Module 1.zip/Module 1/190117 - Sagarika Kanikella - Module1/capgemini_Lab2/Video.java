package capgemini_Lab2;

class Video extends MediaItem {
	 private int yearReleased;
	 private String director,genre;
	public int getRuntime() {
		return runtime;
	}
	public void setRuntime(int runtime) {
		this.runtime = runtime;
	}
	
	public Video() {
		
		//this.runtime = 0;
		this.yearReleased = 0;
		this.director =null;
		this.genre = null;
	}
	public Video(int runtime, int yearReleased, String director, String genre) {
		setDirector(director);
		setGenre(genre);
		setYearReleased(yearReleased);
	}
	public void setYearReleased(int yearReleased) {
		this.yearReleased = yearReleased;
	}
	public void setDirector(String director) {
		this.director = director;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	@Override
	public void setUniqueIdentificationnumber(int uniqueIdentificationnumber) {
		this.uniqueIdentificationnumber = uniqueIdentificationnumber;
	}
	@Override
	public void setNumber_of_Copies(int number_of_Copies) {
		this.number_of_Copies = number_of_Copies;
	}
	@Override
	public void setTitle(String title) {
		this.Title = title;		
	}
	public String getDirector() {
		return director;
	}
	public int getYearReleased() {
		return yearReleased;
	}
	public String getGenre() {
		return genre;
	}
	@Override
	public String getTitle() {
		return Title;
	}

	@Override
	public int getNumber_of_Copies() {
		return number_of_Copies;
	}

	@Override
	public int getUniqueIdentificationnumber() {
		// TODO Auto-generated method stub
		return uniqueIdentificationnumber;
	}
@Override
public String toString() {
	// TODO Auto-generated method stub
	return "Director="+getDirector()+"\nyearReleased="+getYearReleased()+"\nruntime="+getRuntime()+"\nGenre="+getGenre()+"\nUniqueIdentificationNumber=" +getUniqueIdentificationnumber()+"\nTitle="+getTitle()+"\nno of copies="+getNumber_of_Copies();
	}
}
