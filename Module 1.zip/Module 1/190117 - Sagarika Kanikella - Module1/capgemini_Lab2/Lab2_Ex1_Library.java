package capgemini_Lab2;

import java.util.Scanner;

public class Lab2_Ex1_Library {

	public static void main(String[] args) {
		int n;
		Scanner scan = new Scanner(System.in);
		n = scan.nextInt();
		switch (n) {
		case 1:
			Video v = new Video();
			v.setDirector("Trivikram");
			v.setGenre("pop");
			v.setNumber_of_Copies(90);
			v.setRuntime(5);
			v.setTitle("Indra");
			v.setUniqueIdentificationnumber(101);
			v.setYearReleased(2002);

			System.out.println(v.toString());
			break;
		case 2:
			Cd c = new Cd();
			c.setArtist("Ntr");
			c.setGenre("pop");
			c.setNumber_of_Copies(80);
			c.setRuntime(5);
			c.setTitle("cobra");
			c.setUniqueIdentificationnumber(102);

			System.out.println(c.toString());
			break;
		case 3:
			Book b = new Book();

			b.setNumber_of_Copies(90);

			b.setTitle("Indra");
			b.setUniqueIdentificationnumber(101);

			b.setAuthor("ravindar");
			System.out.println(b.toString());
			break;
		case 4:
			JournalPaper j = new JournalPaper();

			j.setNumber_of_Copies(90);

			j.setTitle("Indra");
			j.setUniqueIdentificationnumber(101);
			j.setAuthor("amma");
			j.setYearpublished(1950);
			System.out.println(j.toString());
			break;
		}
	}

}
