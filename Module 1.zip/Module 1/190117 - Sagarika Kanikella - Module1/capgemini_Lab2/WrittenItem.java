package capgemini_Lab2;

public abstract class WrittenItem extends Item {
	protected String author;

	public abstract String getAuthor();
	public abstract void setAuthor(String author);
}
