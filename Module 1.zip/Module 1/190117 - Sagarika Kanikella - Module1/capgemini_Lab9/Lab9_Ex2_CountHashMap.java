package capgemini_Lab9;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;

public class Lab9_Ex2_CountHashMap {

	public static void main(String[] args) {
		String str;
		Scanner scan = new Scanner(System.in);
		str = scan.next();
		char[] c = str.toCharArray();
		Arrays.sort(c);
		HashMap<Character, Integer> hash = new HashMap<Character, Integer>();
		int count = 1;
		for (int i = 0; i < c.length - 1; i++) {

			if (c[i] != c[i + 1]) {
				hash.put(c[i], count);
				count = 1;
			} else {
				count++;

			}
			hash.put(c[c.length - 1], count);
		}
		Iterator<Character> iterator = hash.keySet().iterator();
		while (iterator.hasNext()) {
			char b;
			b = iterator.next();
			System.out.println(b + "=" + hash.get(b));
		}
	}

}
