package capgemini_Lab9;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

public class Lab9_Ex1_getValues {

	public static void main(String[] args) {
		HashMap<Integer, String> hash = new HashMap<Integer, String>();
		hash.put(101, "satish");
		hash.put(302, "mahesh");
		hash.put(20, "manik");
		List<String> list = getValues(hash);
		System.out.println(list);

	}

	private static List<String> getValues(HashMap<Integer, String> hash) {
		List<String> l1 = new ArrayList<String>();
		Iterator<String> iterator = hash.values().iterator();
		while (iterator.hasNext()) {
			l1.add(iterator.next());
		}
		Collections.sort(l1);
		return l1;
	}

}
