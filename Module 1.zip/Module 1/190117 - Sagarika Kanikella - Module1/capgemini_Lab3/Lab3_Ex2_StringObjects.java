package capgemini_Lab3;

import java.util.Arrays;
import java.util.Scanner;

public class Lab3_Ex2_StringObjects {

	public static void main(String[] args) {
		int n,i;
		String str[];
		Scanner scan=new Scanner(System.in);
		n=scan.nextInt();
		scan.nextLine();
    	str=new String[n];
		for(i=0;i<n;i++)
		{
			str[i]=scan.next();
		}
		stringObjects(str);
	}

	private static void stringObjects(String[] str) {
		int j;
		Arrays.sort(str);
		if(str.length%2!=0)
		{
			for( j=0;j<str.length;j++)
			{
				if(j<=(str.length)/2)
				{
					System.out.println(str[j].toUpperCase());
				}
				else
				{
					System.out.println(str[j].toLowerCase());
				}
				
			}
		}
		else
		{
			for( j=0;j<str.length;j++)
			{
				if(j<(str.length)/2)
				{
					System.out.println(str[j].toUpperCase());
				}
				else
				{
					System.out.println(str[j].toLowerCase());
				}
				
			}
		}
		
		
	}

}
