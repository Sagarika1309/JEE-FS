package capgemini_Lab3;

import java.util.Arrays;
import java.util.Scanner;

public class Lab3_Ex3_getSorted {

	public static void main(String[] args) {
		int no, i;
		Scanner scan = new Scanner(System.in);
		no = scan.nextInt();
		int arr[] = new int[no];
		for (i = 0; i < no; i++) {
			arr[i] = scan.nextInt();
		}
     int b[]=getSorted(arr);
     for(int i1:b)
     {
    	 System.out.println(i1);
     }
	}

	private static int[] getSorted(int[] arr) {
		
		
		int i;
		for(i=0;i<arr.length;i++)
		{
			String s;
			StringBuilder str=new StringBuilder("");
			s=str.append(arr[i]).reverse().toString();
			arr[i]=Integer.parseInt(s);
		}
		Arrays.sort(arr);
		return arr;
	
	}

}
