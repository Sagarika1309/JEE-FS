package capgemini_Lab3;

import java.util.Arrays;
import java.util.Scanner;

public class Lab3_Ex1_GetSecondSmallest {

	public static void main(String[] args) {
		int a[],n,i;
		Scanner scan=new Scanner(System.in);
		n=scan.nextInt();
		a=new int[n];
		for(i=0;i<n;i++)
		{
			a[i]=scan.nextInt();
		}
		int sec_small=getSecondSmallest(a);
		System.out.println(sec_small);
	}

	private static int getSecondSmallest(int[] a) {
		Arrays.sort(a);
		return a[1];
	}

}
