package capgemini_Lab8;

import java.util.Scanner;

public class Lab8_Ex5_PositiveString {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		String str1=scan.next(),str;
		str=str1.toLowerCase();
		int flag=1;
		for(int i=0;i<str.length()-1;i++)
		{
			if(str.charAt(i)<=str.charAt(i+1))
			{
				flag=1;
			}
			else
			{
				flag=0;
				break;
			}
		}
		if(flag==1)
		{
			System.out.println("positive String");
		}
		else
		{
			System.out.println("not positive");
		}
		
		
	}

}
