package capgemini_Lab8;

import java.io.File;
import java.util.Scanner;

public class Lab8_Ex4_FileType {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		String path=scan.next();
		File file=new File(path);
		System.out.println("whether file present="+file.exists());
		file.setReadOnly();
		System.out.println("file is readable="+file.canRead());
		System.out.println("file is writeable="+file.canWrite());
		String exten = null;
		int index=path.lastIndexOf('.');
		if(index>=0)
		{
			exten=path.substring(index+1);
		}
		System.out.println("Extension="+exten);
		long length=file.length();
		System.out.println(length+":"+length*Long.SIZE);
	}

}
