package capgemini_Lab8;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.LineNumberReader;
import java.io.Reader;
import java.util.Scanner;

public class Lab8_Ex2_count {

	public static void main(String[] args) throws IOException {
		File file=new File("C:\\capgemini\\dataout.txt");
		try(FileReader fileReader=new FileReader(file))
		{
			LineNumberReader lineNumberReader=new LineNumberReader(fileReader);
			String s=lineNumberReader.readLine();
			while(s!=null)
			{
				System.out.println(lineNumberReader.getLineNumber()+" "+s);
				s=lineNumberReader.readLine();

			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}


	}

}
