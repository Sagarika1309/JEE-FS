package capgemini_Lab8;

import java.util.Scanner;
import java.util.StringTokenizer;

public class Lab8_Ex1_StringTokenise {

	public static void main(String[] args) {
			
		String str;
		int sum=0;
		String key;
		Scanner sc=new Scanner(System.in);
		str=sc.nextLine();
		StringTokenizer s=new StringTokenizer(str);
		while(s.hasMoreTokens())
		{
			key=s.nextToken();
			sum+=Integer.parseInt(key);
			System.out.println(key);
		}
		System.out.println(sum);
	}

}
