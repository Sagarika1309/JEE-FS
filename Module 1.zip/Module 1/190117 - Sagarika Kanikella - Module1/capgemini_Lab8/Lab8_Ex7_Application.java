package capgemini_Lab8;

import java.util.Scanner;

public class Lab8_Ex7_Application {

	public static void main(String[] args) {
		String name;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter User name");
		name=sc.next();
	System.out.println(validate(name));
	}

	private static boolean validate(String name) {
		if(name.length()>=11)
		{
			if(name.endsWith("_job"))
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		else
		{
			return false;
		}
		
	}

}
