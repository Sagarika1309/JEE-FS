package capgemini_Lab8;

import java.time.*;
import java.util.*;

public class Lab8_Ex6_Date1 {  
   public static void main(String[] args)
    {
	   Scanner scan=new Scanner(System.in);
        LocalDate pdate = LocalDate.of(scan.nextInt(), scan.nextInt(),scan.nextInt());
        LocalDate now = LocalDate.now();
 
        Period diff = Period.between(pdate, now);
 
     System.out.printf("\nDifference is %d years, %d months and %d days old\n\n", 
                    diff.getYears(), diff.getMonths()*12, diff.getDays());
  }
   
}