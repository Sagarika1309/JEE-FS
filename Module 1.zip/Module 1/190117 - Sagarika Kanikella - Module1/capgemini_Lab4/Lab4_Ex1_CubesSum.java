package capgemini_Lab4;

import java.util.Scanner;

public class Lab4_Ex1_CubesSum {

	public static void main(String[] args) {
		int no;
		Scanner sc=new Scanner(System.in);
		no=sc.nextInt();
		long sum=cubesSum(no);
		System.out.println(sum);
	}

	private static long cubesSum(int no) {
       int i,temp;
       long sum=0;
       while(no>0)
       {
    	 temp=no%10;
    	 sum+=Math.pow(temp, 3);
    	 no/=10;
       }
		return sum;
	}

}
